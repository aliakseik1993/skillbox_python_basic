numbers = []
for number in range(0, 101):
    numbers.append(number)
print(numbers)