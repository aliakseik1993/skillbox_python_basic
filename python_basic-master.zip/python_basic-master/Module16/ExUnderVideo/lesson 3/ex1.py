matrix = [[1, 2 ,3], [4, 5, 6], [7, 8, 9]]
for i_number in matrix:
    for i_num in i_number:
        print(i_num, end = " ")
    print()
