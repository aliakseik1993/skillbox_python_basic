name = input("Имя: ")
money_back = int(input("Долг: "))
print("{0}! {0}, привет! Как дела, {0}? Где мои {1} рублей? {0}!".format(name, money_back))