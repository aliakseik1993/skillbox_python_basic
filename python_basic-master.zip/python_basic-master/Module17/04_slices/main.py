alphabet = 'abcdefg'
copy_string = alphabet[:]
print("1:", copy_string)
print("2:", alphabet[6::-1])
print("3:", alphabet[0::2])
print("4:", alphabet[1::2])
print("5:", alphabet[:1])
print("6:", alphabet[6:5:-1])
print("7:", alphabet[3:4])
print("8:", alphabet[4:7])
print("9:", alphabet[3:5])
print("10:", alphabet[4:2:-1])