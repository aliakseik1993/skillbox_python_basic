menu = input("Доступное меню: ").split(";")
print("На данный момент в меню есть:", ", ".join(menu))
