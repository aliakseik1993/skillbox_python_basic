text = input("Введите текст: ").split()
print(" ".join(text))
