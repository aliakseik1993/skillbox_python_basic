nums = [48, -10, 9, 38, 17, 50, -5, 43, 46, 12]

print(nums[:6])
print(nums[:8])
print(nums[2::2])
print(nums[1::2])
print(nums[::-1])
print(nums[::-2])