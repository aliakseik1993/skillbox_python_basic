list_new = [i for i in range (1, 5) for i in [list(range(i, 10 + i, 4))]]
print(list_new)
