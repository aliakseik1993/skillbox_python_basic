line = input("Введите строку: ")
print("Результат:", line.title())
